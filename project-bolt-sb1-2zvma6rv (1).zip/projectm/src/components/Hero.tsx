import React from 'react';
import { TypeAnimation } from 'react-type-animation';
import { Download, Mail, MousePointerClick, ArrowDown } from 'lucide-react';
import { motion } from 'framer-motion';

const Hero = () => {
  return (
    <section className="min-h-screen relative overflow-hidden bg-gradient-to-br from-gray-900 via-primary-900 to-secondary-900">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute w-[500px] h-[500px] bg-primary-500/20 rounded-full blur-3xl -top-48 -left-24 animate-pulse" />
        <div className="absolute w-[400px] h-[400px] bg-secondary-500/20 rounded-full blur-3xl -bottom-32 -right-24 animate-pulse delay-1000" />
      </div>

      <div className="container mx-auto px-4 py-16 relative">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-12 pt-20">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="flex-1 text-center lg:text-left"
          >
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight">
              Transforming <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary-400 to-secondary-400">Digital Presence</span> Into Results
            </h1>
            
            <div className="h-16 mb-8 text-xl md:text-2xl text-gray-300">
              <TypeAnimation
                sequence={[
                  'SEO Specialist 🔍',
                  1500,
                  'Social Media Expert 📱',
                  1500,
                  'Content Strategist ✍️',
                  1500,
                  'Digital Growth Hacker 🚀',
                  1500,
                ]}
                wrapper="div"
                speed={50}
                repeat={Infinity}
              />
            </div>

            <p className="text-gray-400 text-lg mb-8 max-w-xl mx-auto lg:mx-0">
              Helping businesses achieve exponential growth through strategic digital marketing solutions and data-driven strategies.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-4 bg-gradient-to-r from-primary-500 to-secondary-500 rounded-full font-semibold text-white flex items-center justify-center gap-2 hover:shadow-lg hover:shadow-primary-500/25 transition-all group"
              >
                <Mail className="w-5 h-5 group-hover:rotate-12 transition-transform" />
                Let's Talk
              </motion.button>
              
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-4 bg-white/10 backdrop-blur-lg rounded-full font-semibold text-white flex items-center justify-center gap-2 hover:bg-white/20 transition-all group"
              >
                <Download className="w-5 h-5 group-hover:translate-y-1 transition-transform" />
                Download CV
              </motion.button>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
            className="flex-1 relative"
          >
            <div className="relative w-72 h-72 md:w-96 md:h-96 mx-auto">
              <div className="absolute inset-0 bg-gradient-to-br from-primary-500 to-secondary-500 rounded-full blur-2xl opacity-50 animate-pulse" />
              <img
                src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80"
                alt="Gaurav Singh Parihar"
                className="relative w-full h-full object-cover rounded-full border-4 border-white/20 p-2"
              />
              <div className="absolute -right-4 top-1/4 bg-white/10 backdrop-blur-lg rounded-2xl p-4 shadow-xl">
                <p className="text-white font-semibold">5+ Years Experience</p>
              </div>
              <div className="absolute -left-4 bottom-1/4 bg-white/10 backdrop-blur-lg rounded-2xl p-4 shadow-xl">
                <p className="text-white font-semibold">100+ Projects</p>
              </div>
            </div>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1, duration: 0.5 }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2"
        >
          <button className="text-white/60 hover:text-white transition-colors flex flex-col items-center gap-2">
            <span className="text-sm">Scroll to explore</span>
            <ArrowDown className="w-5 h-5 animate-bounce" />
          </button>
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;