import React from 'react';
import { motion } from 'framer-motion';
import { Rocket, CheckCircle2 } from 'lucide-react';

const reasons = [
  {
    title: 'Proven Track Record',
    description: 'Consistently delivered outstanding results with measurable ROI for clients across various industries.'
  },
  {
    title: 'Data-Driven Approach',
    description: 'Every strategy is backed by thorough research, analytics, and industry best practices.'
  },
  {
    title: 'Innovative Solutions',
    description: 'Stay ahead of digital marketing trends and implement cutting-edge strategies for optimal results.'
  },
  {
    title: 'Dedicated Partnership',
    description: 'Your success is my priority. I work closely with clients to ensure goals are not just met, but exceeded.'
  }
];

const WhyChooseMe = () => {
  return (
    <section className="py-20 bg-gradient-to-br from-primary-500 via-secondary-500 to-primary-700 text-white">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <Rocket className="w-12 h-12 mx-auto mb-4" />
          <h2 className="text-4xl font-bold mb-4">Why Choose Me?</h2>
          <p className="max-w-2xl mx-auto opacity-90">
            Partner with a digital marketing expert who is passionate about helping brands achieve exceptional growth
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {reasons.map((reason, index) => (
            <motion.div
              key={reason.title}
              initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2 }}
              className="bg-white/10 backdrop-blur-lg rounded-xl p-6 hover:bg-white/20 transition-colors duration-300"
            >
              <div className="flex items-start">
                <CheckCircle2 className="w-6 h-6 text-secondary-300 flex-shrink-0 mt-1" />
                <div className="ml-4">
                  <h3 className="text-xl font-semibold mb-2">{reason.title}</h3>
                  <p className="opacity-90">{reason.description}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mt-12"
        >
          <button className="bg-white text-primary-600 px-8 py-3 rounded-full font-semibold hover:bg-primary-50 transition-colors inline-flex items-center">
            Let's Work Together
            <Rocket className="w-5 h-5 ml-2" />
          </button>
        </motion.div>
      </div>
    </section>
  );
};

export default WhyChooseMe;