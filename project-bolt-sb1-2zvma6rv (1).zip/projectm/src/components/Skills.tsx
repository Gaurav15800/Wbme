import React from 'react';
import { motion, useAnimation } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Zap, Star } from 'lucide-react';

const skills = [
  { name: 'SEO', level: 90 },
  { name: 'Social Media Marketing', level: 85 },
  { name: 'Content Management', level: 88 },
  { name: 'Content Strategy', level: 92 },
  { name: 'Content Writing', level: 87 },
  { name: 'Graphic Designing', level: 75 },
  { name: 'Video Editing', level: 70 },
  { name: 'Advertising', level: 82 }
];

const tools = [
  { name: 'Semrush', rating: 3, logo: 'https://www.semrush.com/static/images/semrush-logo-small.png' },
  { name: 'ChatGPT', rating: 3, logo: 'https://upload.wikimedia.org/wikipedia/commons/0/04/ChatGPT_logo.svg' },
  { name: 'Google Analytics', rating: 3, logo: 'https://www.google.com/analytics/images/ga-icon-1200x1200.png' },
  { name: 'Surfer SEO', rating: 3, logo: 'https://surferseo.com/assets/images/logo-icon.svg' },
  { name: 'WordPress', rating: 3, logo: 'https://s.w.org/style/images/about/WordPress-logotype-standard.png' },
  { name: 'Meta Ads', rating: 2, logo: 'https://www.facebook.com/images/fb_icon_325x325.png' },
  { name: 'Google Ads', rating: 2, logo: 'https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_272x92dp.png' },
  { name: 'Mailerlite', rating: 2, logo: 'https://www.mailerlite.com/assets/SEO/mailerlite-logo.png' },
  { name: 'Sitechecker', rating: 3, logo: 'https://sitechecker.pro/wp-content/themes/sitechecker/assets/images/logo.svg' },
  { name: 'DeepAI', rating: 3, logo: 'https://deepai.org/static/images/logo.png' },
  { name: 'YouTube Studio', rating: 3, logo: 'https://www.youtube.com/about/static/media/logo-red.4b341a3d.svg' },
  { name: 'Canva', rating: 3, logo: 'https://static.canva.com/static/images/logo_canva_white.svg' },
  { name: 'Rankmath', rating: 3, logo: 'https://rankmath.com/wp-content/themes/rank-math/common/img/logo.svg' },
  { name: 'Yoast SEO', rating: 3, logo: 'https://yoast.com/app/themes/yoast-com/assets/images/Yoast_SEO_Icon.svg' },
  { name: 'Google Adsense', rating: 3, logo: 'https://www.google.com/adsense/start/images/adsense-logo.png' },
  { name: 'Jasper', rating: 3, logo: 'https://assets-global.website-files.com/60e5f2de011b86acebc30db7/60e5f2de011b86c6abc31174_jasper-logo.svg' }
];

const ProgressBar = ({ skill, inView }: { skill: typeof skills[0], inView: boolean }) => {
  return (
    <div className="mb-6">
      <div className="flex justify-between items-center mb-2">
        <span className="text-white font-medium">{skill.name}</span>
        <span className="text-primary-400 font-semibold">{skill.level}%</span>
      </div>
      <div className="h-3 bg-gray-700 rounded-full overflow-hidden">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: inView ? `${skill.level}%` : 0 }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="h-full bg-gradient-to-r from-primary-500 to-secondary-500 rounded-full"
        />
      </div>
    </div>
  );
};

const Skills = () => {
  const controls = useAnimation();
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  });

  React.useEffect(() => {
    if (inView) {
      controls.start('visible');
    }
  }, [controls, inView]);

  return (
    <section className="py-20 bg-gray-900" id="skills">
      <div className="container mx-auto px-4">
        <motion.div
          ref={ref}
          initial="hidden"
          animate={controls}
          variants={{
            visible: { opacity: 1, y: 0 },
            hidden: { opacity: 0, y: 20 }
          }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <Zap className="w-12 h-12 text-primary-500 mx-auto mb-4" />
          <h2 className="text-4xl font-bold text-white mb-4">My Expertise</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Leveraging years of experience in digital marketing to deliver exceptional results
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto mb-16">
          {skills.map((skill) => (
            <ProgressBar key={skill.name} skill={skill} inView={inView} />
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-gray-800 rounded-2xl p-8"
        >
          <h3 className="text-2xl font-bold text-white mb-8 text-center">Tools I Master</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6">
            {tools.map((tool) => (
              <motion.div
                key={tool.name}
                whileHover={{ scale: 1.05 }}
                className="bg-gray-700/50 rounded-xl p-4 flex flex-col items-center gap-2 group hover:bg-gray-700 transition-colors"
              >
                <img
                  src={tool.logo}
                  alt={tool.name}
                  className="w-12 h-12 object-contain mb-2 group-hover:scale-110 transition-transform"
                />
                <span className="text-sm text-gray-300 text-center">{tool.name}</span>
                <div className="flex gap-1">
                  {[...Array(tool.rating)].map((_, i) => (
                    <Star
                      key={i}
                      className="w-4 h-4 text-yellow-400"
                      fill="currentColor"
                    />
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Skills;